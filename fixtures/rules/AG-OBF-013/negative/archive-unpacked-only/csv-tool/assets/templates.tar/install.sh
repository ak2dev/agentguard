echo installing templates
